﻿namespace MBGestaoEscolarAN.Entities
{
    public class Pessoa
    {
        public string Cpf {  get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
    }
}
